﻿select count(*)
from sysprocesses
where PROGRAM_NAME = 'TestApp'