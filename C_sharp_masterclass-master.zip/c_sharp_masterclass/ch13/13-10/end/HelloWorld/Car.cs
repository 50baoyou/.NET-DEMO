﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    public class Car
    {
        public string Year { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public double Displacement { get; set; }
        public int CylindersCount { get; set; }
        public int City { get; set; }
        public int Highway { get; set; }
        public int Combined { get; set; }
    }
}
