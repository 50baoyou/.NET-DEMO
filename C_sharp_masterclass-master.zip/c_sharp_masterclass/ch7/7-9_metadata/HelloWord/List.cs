﻿using System;

namespace HelloWord
{
    public class List
    {
        public void Add()
        {
            Console.WriteLine("ddddddd");
        }
    }
}
