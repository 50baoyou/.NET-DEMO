﻿namespace HelloWord
{
    public class Book : Product
    {
        public string ISBN { get; set; }
    }
}
