﻿using System;

namespace HelloWord
{
    internal class MailService
    {

    }
}