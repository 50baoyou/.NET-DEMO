﻿using System;
namespace HelloWord
{
    public class SmsMessageService
    {

    }
}
