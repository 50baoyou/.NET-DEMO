﻿using System;
using System.Collections.Generic;

namespace HelloWord
{
    public class OrderProcessor
    {

        public void Process(Order order)
        {
            // 订单处理...

            // 订单处理完成，发送订单处理完成事件

        }
    }
}
