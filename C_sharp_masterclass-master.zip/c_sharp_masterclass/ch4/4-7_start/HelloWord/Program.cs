﻿using System;

namespace HelloWord
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Read();
        }
    }
}
