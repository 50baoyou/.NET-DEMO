﻿using System;

namespace HelloWord
{
    public class Car
    {
        public void Accelerate()
        {
            Console.WriteLine("加油");
        }

        private void Stop()
        {
            Console.WriteLine("制动");
        }
    }
}
