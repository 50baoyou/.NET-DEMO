﻿namespace CMS
{
    public interface ICMSController
    {
        void Start();
    }
}