﻿namespace CMS
{
    public interface IMenu
    {
        void ShowMenu();
    }
}