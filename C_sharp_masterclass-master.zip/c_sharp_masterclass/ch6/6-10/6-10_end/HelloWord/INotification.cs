﻿namespace HelloWord
{
    public interface INotification
    {
        public void Send(string message);
    }
}