﻿using System;

namespace HelloWord
{
    internal class MailService
    {
        public void Send(string message)
        {
            Console.WriteLine(message);
        }
    }
}