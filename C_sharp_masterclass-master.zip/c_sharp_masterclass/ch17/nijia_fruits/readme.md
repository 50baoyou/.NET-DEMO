## 如何启动游戏？
- 先安装unity
- 打开课程项目
- 在unity底部文件浏览器中找到“Assets”文件夹，然后进入Sence文件夹，双击打开“SimpleSence”。
- 点击顶部三角播放键，游戏即可启动。