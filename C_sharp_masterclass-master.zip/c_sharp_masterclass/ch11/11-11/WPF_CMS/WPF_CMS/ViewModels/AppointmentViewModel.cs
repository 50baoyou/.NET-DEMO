﻿namespace WPF_CMS.ViewModels
{
    public class AppointmentViewModel
    {
    }
}